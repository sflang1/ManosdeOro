Entra al index
Se redirecciona a Interfaces
<meta http-equiv="REFRESH" content="2,url=Interfaces">