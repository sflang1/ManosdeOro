<?php
	$dbhost="localhost";
	$dbName="manosdeoro2";
	$dbUser="root";
	$dbPassword="";
	$filelocation="../Archivos";
?>