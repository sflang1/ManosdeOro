function ir_facebook() 
{
	location.href="https://www.facebook.com/pages/ManosdeOro-Popayan/1424524214510376?fref=ts"
} 

function ir_twiter() 
{
	location.href="https://twitter.com/manosdeoropop"
} 

function ir_instagram() 
{
	location.href="http://cdamanosdeoro.blogspot.com/"
} 

function ir_youtube() 
{
	location.href="https://www.youtube.com/watch?v=4ibF0MZ6JTU&index=10&list=PL5E2AEEBD122E066C"
} 

function ir_inicio() 
{
	location.href="../Interfaces/index.php"
} 
function ir_eventos() 
{
	location.href="../Interfaces/eventos.php"
} 
function ir_acerca() 
{
	location.href="../Interfaces/acerca.php"
}
function ir_expositores() 
{
	location.href="../Interfaces/expositores.php"
}
function ir_contacto() 
{
	location.href="../Interfaces/contacto.php"
}

function ir_tienda() 
{
	location.href="../Interfaces/tiendaVirtual.php"
} 
function ir_cursos() 
{
	location.href="../Interfaces/ofertaCursos.php"
} 

